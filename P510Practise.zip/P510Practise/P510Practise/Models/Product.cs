﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace P510Practise.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        [Required]
        public double Price { get; set; }

        public double DiscountPercent { get; set; }

        [Required]
        public int Rate { get; set; }

        [Required]
        public double ExTax { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string Tags { get; set; }

        [Required]
        public string Code { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<ProductImage> ProductImages { get; set; }

        public ICollection<ProductCategory> ProductCategories { get; set; }

        [NotMapped] 
        public IFormFile[] Photos { get; set; } 
    }
}
