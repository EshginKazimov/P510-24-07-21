﻿using Microsoft.AspNetCore.Http;

namespace P510Practise.Areas.AdminPanel.Data
{
    public static class Extensions
    {
        public static bool IsImage(this IFormFile file)
        {
            return file.ContentType.Contains("image");
        }

        public static bool IsSizeAllowed(this IFormFile file, int mb)
        {
            return file.Length < mb * 1024 * 1024;
        }
    }
}
