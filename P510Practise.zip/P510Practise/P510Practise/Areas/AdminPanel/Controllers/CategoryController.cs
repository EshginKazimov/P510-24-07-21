﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using P510Practise.Areas.AdminPanel.Data;
using P510Practise.DataAccessLayer;
using P510Practise.Models;

namespace P510Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class CategoryController : Controller
    {
        private readonly AppDbContext _dbContext;

        public CategoryController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var categories = await _dbContext.Categories.Where(x => x.IsDeleted == false).ToListAsync();

            return View(categories);
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.ParentCategories = await _dbContext.Categories.
                Where(x => x.IsDeleted == false && x.IsMain == true).ToListAsync();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category, int? parentCategoryId)
        {
            ViewBag.ParentCategories = await _dbContext.Categories.
                Where(x => x.IsDeleted == false && x.IsMain == true).ToListAsync();

            if (!ModelState.IsValid)
            {
                return View();
            }

            if (category.IsMain)
            {
                if (await _dbContext.Categories.AnyAsync(x => x.IsDeleted == false && x.IsMain &&
                                                              x.Name.ToLower() == category.Name.ToLower()))
                {
                    ModelState.AddModelError("", "Bele adda kateqoriya var.");
                    return View();
                }

                if (!category.Photo.IsImage())
                {
                    ModelState.AddModelError("", "Yuklediyiniz file shekil deyil.");
                    return View();
                }

                if (!category.Photo.IsSizeAllowed(1))
                {
                    ModelState.AddModelError("", "Yuklediyiniz shekilin olchusu 1Mb-dan artiqdir.");
                    return View();
                }

                var imageName = await FileManager.GenerateFileAsync(category.Photo, Constants.ImageFolderPath);

                category.Image = imageName;
            }
            else
            {
                if (parentCategoryId == null)
                {
                    ModelState.AddModelError("", "Parent category sechin.");
                    return View();
                }

                var parentCategory = await _dbContext.Categories
                    .Include(x => x.Children.Where(y => y.IsDeleted == false))
                    .FirstOrDefaultAsync(x => x.IsDeleted == false &&
                                              x.IsMain &&
                                              x.Id == parentCategoryId);
                if (parentCategory == null)
                {
                    return NotFound();
                }

                if (parentCategory.Children.Any(x => x.Name.ToLower() == category.Name.ToLower()))
                {
                    ModelState.AddModelError("", $"{parentCategory.Name}-in childrenlarinda {category.Name} adda kateqoriya var.");
                    return View();
                }

                category.Parent = parentCategory;
            }

            category.IsDeleted = false;
            await _dbContext.Categories.AddAsync(category);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var category = await _dbContext.Categories.Include(x => x.Children.Where(y => y.IsDeleted == false))
                .Include(x => x.Parent)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (category == null)
                return NotFound();

            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteCategory(int? id)
        {
            if (id == null)
                return NotFound();

            var category = await _dbContext.Categories.Include(x => x.Children.Where(y => y.IsDeleted == false))
                .FirstOrDefaultAsync(x => x.Id == id);
            if (category == null)
                return NotFound();

            category.IsDeleted = true;
            if (category.IsMain)
            {
                foreach (var child in category.Children)
                {
                    child.IsDeleted = true;
                }
            }

            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
