﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using P510Practise.DataAccessLayer;

namespace P510Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Create()
        {
            var parentCategories = await _dbContext.Categories.Where(x => x.IsMain && x.IsDeleted == false)
                .Include(x => x.Children.Where(y => y.IsDeleted == false)).ToListAsync();

            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = parentCategories[0].Children.ToList();

            return View();
        }

        public async Task<IActionResult> GetChildCategories(int? parentCategoryId)
        {
            if (parentCategoryId == null)
                return NotFound();

            //var category = await _dbContext.Categories.Include(x => x.Children.Where(y => y.IsDeleted == false))
            //    .FirstOrDefaultAsync(x => x.Id == parentCategoryId);

            //if (category == null)
            //    return NotFound();

            //return PartialView("_CategoryPartial", category.Children.ToList());

            var childCategories = await _dbContext.Categories.Include(x => x.Parent)
                .Where(x => x.IsDeleted == false &&
                            x.IsMain == false &&
                            x.Parent.Id == parentCategoryId).ToListAsync();

            return PartialView("_CategoryPartial", childCategories);
        }
    }
}
